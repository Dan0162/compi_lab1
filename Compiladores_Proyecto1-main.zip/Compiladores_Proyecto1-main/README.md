# Diagrama de Clases
![Diagrama de clases UML](https://github.com/user-attachments/assets/5d781e93-e9e4-49bb-a32b-f6e40931d392)
